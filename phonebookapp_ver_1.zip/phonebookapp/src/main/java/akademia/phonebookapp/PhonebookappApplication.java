package akademia.phonebookapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PhonebookappApplication {

    public static void main(String[] args) {
        SpringApplication.run(PhonebookappApplication.class, args);
    }

}

